package ie.tudublin;

import processing.data.TableRow;

public class Task
{
    private String Task;
    private int Start;
    private int End;

    public Task(String Task, int Start, int End) {
        this.Task = Task;
        this.Start = Start;
        this.End = End;
    }
	public void setStart(int Start) {
        this.Start = Start;
    }
    
    public void setEnd(int End) {
        this.End = End;
    }

    public String getTask() {
        return this.Task;
    }

    public int getStart() {
        return this.Start;
    }

    public int getEnd() {
        return this.End;
    }

    public Task(TableRow tr) {
        this(tr.getString("Task"), tr.getInt("Start"), tr.getInt("End"));
    }

	@Override
    public String toString() {
        return "{" +
            " Task='" + getTask() + "'" +
            ", Start='" + getStart() + "'" +
            ", End='" + getEnd() + "'" +
            "}";
    }
}
    