package ie.tudublin;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.data.Table;
import processing.data.TableRow;

public class Gantt extends PApplet
{	
	public ArrayList<Task> tasks = new ArrayList<Task>();
	float w;

	private int leftSideSpace = 150;
	private int rectangleSize = 35;
	private int spaceSize = 35;
	
	private float dragSize = 20f;
	private int Right = -1;
    private int Left = -1;

	public void settings()
	{
		size(800, 600);
	}

	public void loadTasks()
	{
		Table t = loadTable("tasks.csv", "header");
		for(TableRow row:t.rows())
			{
				Task tsk = new Task(row);
				tasks.add(tsk);
			}
	}

	public void printTasks()
	{
		for(Task t:tasks)
		{
			String Task = t.getTask();
			int Start = t.getStart();
			int End = t.getEnd();
			print(Task + ",");
			print(Start + ",");
			println(End);
		}
	}
	
	public void displayTasks()
	{
		for(int i = 0 ; i < tasks.size() ; i ++)
		{
			Task task = tasks.get(i);

			float y = map(i, 0, tasks.size(), 100, height - 100);
			fill(255);
			text(task.getTask(), 45, y);

			float start = map(task.getStart(), 1, 30, leftSideSpace, width - spaceSize);
			float end = map(task.getEnd(), 1, 30, leftSideSpace, width - spaceSize);
			fill(y,255,255);
			rect(start, y - (rectangleSize / 2), end - start, rectangleSize, 5, 5, 5, 5);
		}

		for(int i = 1 ; i <= 30 ; i ++)
		{
			float x = map(i, 1, 30, leftSideSpace, width - spaceSize);
			stroke(255);
			line(x, 75, x, height - 125);
			fill(255);
			text(i, x - 2, w/2);
		}
	}

	public void mousePressed()
	{
		for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);

            float upperLeft = map(task.getStart(), 1, 30, leftSideSpace, width - spaceSize);
            float upperRight = map(task.getEnd(), 1, 30, leftSideSpace, width - spaceSize);

            float downLeft = map(i, 0, tasks.size(), spaceSize * 2, height - spaceSize) - (rectangleSize / 2);
            float downRight = downLeft + upperRight;

            if (mouseY >= downLeft && mouseY <= downRight) {
                if (mouseX > upperLeft - dragSize && mouseX < upperLeft + dragSize) {
                    Left = i;
                    Right = -1;
                } else if (mouseX > upperRight - dragSize && mouseX < upperRight + dragSize) {
                    Right = i;
                    Left = -1;
                } else {
                    Right = -1;
                    Left = -1;
                }
            }
        }
	}

	public void mouseDragged()
	{
		int position = (int) (1 + 30 * ((mouseX - (leftSideSpace - dragSize)) / (width - (leftSideSpace - dragSize))));

        if (Left >= 0) {
            Task task = tasks.get(Left);

            if (position > 0 && position < task.getEnd()) {
                task.setStart(position);
			}

        } else if (Right >= 0) {
            Task task = tasks.get(Right);

            if (position <= 30 && position > task.getStart()) {
                task.setEnd(position);
            }
        }
	}

	
	
	public void setup() 
	{
		w = width * 0.1f;
		loadTasks();
		printTasks();
	}
	
	public void draw()
	{	
		colorMode(HSB);		
		background(0);
		displayTasks();

		for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);

            float upperLeft = map(task.getStart(), 1, 30, leftSideSpace, width - spaceSize);
            float upperRight = map(task.getEnd(), 1, 30, leftSideSpace, width - spaceSize);

            float downLeft = map(i, 0, tasks.size(), spaceSize * 3, height - spaceSize) - (rectangleSize / 2);
            float downRight = downLeft + upperRight;

            if (mouseY >= downLeft && mouseY <= downRight) {
                if (mouseX > upperLeft - dragSize && mouseX < upperLeft + dragSize || mouseX > upperRight - dragSize && mouseX < upperRight + dragSize) {
                    cursor(HAND);
                } else {
                    cursor(ARROW);
                }
            }
        }
	}
}
